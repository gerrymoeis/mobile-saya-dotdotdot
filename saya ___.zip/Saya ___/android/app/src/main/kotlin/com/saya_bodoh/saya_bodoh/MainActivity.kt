package com.saya_bodoh.saya_bodoh

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
