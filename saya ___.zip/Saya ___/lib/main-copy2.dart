import 'package:flutter/material.dart';

void main() => runApp(
  MaterialApp(
    darkTheme: ThemeData.dark(),
    home: Scaffold(
      body: Builder(builder: (context) {
        int count = 0;

        return StatefulBuilder(
          builder: (context, setState) => GestureDetector(
            onTap: () {
              setState(() => count++);
            },
            child: Container(
              color: Colors.black,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (count >= 10) Image.asset('assets/meme.jpeg', height: 150),
                  Text(
                    count < 10
                        ? "Klik 10 kali untuk dapat uang!"
                        : "Dasar bodoh!",
                    style: const TextStyle(
                        fontSize: 24,
                        color: Colors.white
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 20),
                    child: Text(
                      "Total klik: $count",
                      style: const TextStyle(
                          color: Colors.yellow,
                          fontSize: 16
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        );
      }),
    ),
  ),
);