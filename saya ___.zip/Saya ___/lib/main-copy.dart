import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Saya Bodoh',
      theme: ThemeData.dark(),
      home: const ClickerScreen(),
    );
  }
}

class ClickerScreen extends StatefulWidget {
  const ClickerScreen({super.key});

  @override
  State<ClickerScreen> createState() => _ClickerScreenState();
}

class _ClickerScreenState extends State<ClickerScreen> {
  int counter = 0;
  int currentLevel = 0;

  final List<Map<String, dynamic>> levels = [
    {
      'target': 10,
      'message': "Klik 10 kali untuk mendapatkan Rp 100.000!",
    },
    {
      'target': 25,
      'message': "Selamat, untuk mencairkannya, klik sampai 25 kali",
    },
    {
      'target': 50,
      'message': "Dasar bodoh, kalau mau uang ya kerja!",
      'image': 'assets/meme.jpeg',
    },
    {
      'target': 100,
      'message': "Hei, anda nggak punya kerjaan ya...",
    },
  ];

  void handleClick() {
    setState(() {
      counter++;

      // Cek jika sudah mencapai target level saat ini
      if (currentLevel < levels.length - 1 &&
          counter >= levels[currentLevel]['target']) {
        currentLevel++;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GestureDetector(
        onTap: handleClick,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Tampilkan gambar jika ada
              if (levels[currentLevel]['image'] != null)
                Image.asset(
                  levels[currentLevel]['image'],
                  height: 200,
                ),

              const SizedBox(height: 20),

              // Tampilkan pesan
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  levels[currentLevel]['message'],
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 24),
                ),
              ),

              const SizedBox(height: 40),

              // Tampilkan counter
              Text(
                'Total klik: $counter',
                style: const TextStyle(
                    fontSize: 18,
                    color: Colors.grey
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}