import 'package:flutter/material.dart';
import 'dart:math';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const ProfileGenerator(),
    );
  }
}

class ProfileGenerator extends StatefulWidget {
  const ProfileGenerator({super.key});

  @override
  State<ProfileGenerator> createState() => _ProfileGeneratorState();
}

class _ProfileGeneratorState extends State<ProfileGenerator> {
  final List<Map<String, String>> _jobs = [
    {'job': 'Pemakan Bakso', 'image': 'assets/bakso.png', 'fact': '🏆 Juara nasional makan bakso cepat'},
    {'job': 'Raja TikTok', 'image': 'assets/tiktok.png', 'fact': '📱 10 followers · 9 akun bot'},
    {'job': 'Ahli Rebahan', 'image': 'assets/bantal.png', 'fact': '💤 Rekor tidur 16 jam non-stop'},
  ];

  String _name = '';
  late Map<String, String> _selectedJob = _jobs[0];
  final TextEditingController _nameController = TextEditingController();

  void _generateProfile() => setState(() {
    _name = _nameController.text;
    _selectedJob = _jobs[Random().nextInt(_jobs.length)];
  });

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Saya ...', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.blueGrey[900],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF2A2A72), Color(0xFF009FFD)],
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: _nameController,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    labelText: 'Masukkan Nama ...',
                    labelStyle: const TextStyle(color: Colors.white70),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white.withOpacity(0.5)),
                    ),
                    focusedBorder: const OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.white)),
                  ),
                  onSubmitted: (_) => _generateProfile(),
                ),
                const SizedBox(height: 15),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white.withOpacity(0.2),
                    padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                      side: BorderSide(color: Colors.white.withOpacity(0.3)),
                    ),
                  ),
                  onPressed: _generateProfile,
                  child: const Text('Enter',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          letterSpacing: 1.2)),
                ),
                if (_name.isNotEmpty) ...[
                  const SizedBox(height: 30),
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(color: Colors.white.withOpacity(0.2)),
                    ),
                    child: Column(
                      children: [
                        Text('Nama Saya $_name',
                            style: const TextStyle(
                                fontSize: 24,
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                shadows: [Shadow(blurRadius: 10, color: Colors.black54)]
                            )),
                        const SizedBox(height: 10),
                        Text('Saya ${_selectedJob['job']}',
                            style: TextStyle(
                                fontSize: 20,
                                color: Colors.lightBlue[100],
                                fontWeight: FontWeight.w500)),
                        const SizedBox(height: 15),
                        Image.asset(_selectedJob['image']!, height: 100),
                        const SizedBox(height: 15),
                        Text(_selectedJob['fact']!,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.white.withOpacity(0.9),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}